# Upgrade Plan: sales-management (20260331072722)

- **Generated**: 2026-03-31 07:27:22
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A
- **Note**: Git is not available for this project. Changes will not be version-controlled during this upgrade.

## Available Tools

**JDKs**
- JDK 21.0.7: `C:\Program Files\Eclipse Adoptium\jdk-21.0.7.6-hotspot\bin` (current project JDK, used by step 2)
- JDK 25: `C:\Users\DonNguyen\.jdk\jdk-25\bin` (target JDK, installed in step 1, used by steps 3 and 4)

**Build Tools**
- Maven Wrapper: 3.9.9 (`.mvn/wrapper/maven-wrapper.properties`) — compatible with Java 25 compilation

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred. ## Options

- Working branch: appmod/java-upgrade-20260331072722 - Run tests before and after the upgrade: true ## Upgrade Goals

- Upgrade Java from 21 to 25 (latest LTS)

### Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java | 21 | 25 | User requested: latest LTS |
| Spring Boot | 3.3.5 | 3.3.5 | Already compatible with Java 25; no upgrade needed |
| Maven Wrapper | 3.9.9 | 3.9.0 | Already compatible — Maven 3.9+ supports Java 25 compilation |
| springdoc-openapi | 2.6.0 | 2.6.0 | Already compatible with Java 25 |

### Derived Upgrades

- No derived upgrades required: Spring Boot 3.3.5, Maven Wrapper 3.9.9, and all dependencies are already compatible with Java 25.

## Upgrade Steps

- **Step 1: Setup Environment**
  - **Rationale**: Install JDK 25 (the target LTS version) required for compilation and testing.
  - **Changes to Make**:
    - [x] Install JDK 25 via `#appmod-install-jdk` (already done during planning)
    - [ ] Verify JDK 25 is available at `C:\Users\DonNguyen\.jdk\jdk-25\bin`
  - **Verification**:
    - Command: `#appmod-list-jdks` to confirm JDK 25 is available
    - Expected: JDK 25 present at `C:\Users\DonNguyen\.jdk\jdk-25\bin`

---

- **Step 2: Setup Baseline**
  - **Rationale**: Establish pre-upgrade compile and test results using Java 21 to measure upgrade success against.
  - **Changes to Make**:
    - [ ] Run baseline compilation with JDK 21
    - [ ] Run baseline tests with JDK 21 and document pass rate
  - **Verification**:
    - Command: `set JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21.0.7.6-hotspot && mvnw.cmd clean test-compile -q && mvnw.cmd clean test -q`
    - JDK: JDK 21 (`C:\Program Files\Eclipse Adoptium\jdk-21.0.7.6-hotspot\bin`)
    - Expected: Document SUCCESS/FAILURE and test pass rate (forms acceptance criteria)

---

- **Step 3: Upgrade Java Version to 25**
  - **Rationale**: Update `java.version` property in `pom.xml` from 21 to 25. This is the only change needed since Spring Boot 3.3.5 and Maven Wrapper 3.9.9 are already compatible with Java 25.
  - **Changes to Make**:
    - [ ] Update `<java.version>21</java.version>` → `<java.version>25</java.version>` in `pom.xml`
  - **Verification**:
    - Command: `set JAVA_HOME=C:\Users\DonNguyen\.jdk\jdk-25 && mvnw.cmd clean test-compile -q`
    - JDK: JDK 25 (`C:\Users\DonNguyen\.jdk\jdk-25\bin`)
    - Expected: Compilation SUCCESS (tests may fail — will be fixed in Final Validation)

---

- **Step 4: Final Validation**
  - **Rationale**: Verify all upgrade goals are met, the project compiles and all tests pass with Java 25. During execution, it was discovered that Spring Boot 3.3.5 (Spring Framework 6.1.14) bundles an old ASM that does NOT support Java 25 class file major version 69. Spring Boot was upgraded to 3.5.13 (Spring Framework 6.2.x) to fix this.
  - **Changes to Make**:
    - [x] `pom.xml`: `spring-boot-starter-parent` 3.3.5 → 3.5.13 (required for Java 25 ASM compatibility)
    - [x] Verify `java.version` is 25 in `pom.xml`
    - [x] Run full test suite with JDK 25; fix any test failures iteratively
  - **Verification**:
    - Command: `mvn clean test`
    - JDK: JDK 25 (`C:\Users\DonNguyen\.jdk\jdk-25\bin`)
    - Result: ✅ Compilation SUCCESS | ✅ Tests: 7/7 passed (100%)

## Key Challenges

- **Java 25 ASM Incompatibility**: Spring Boot 3.3.5 uses Spring Framework 6.1.14, which bundles an old ASM library that does NOT support Java 25 class file major version 69. This required upgrading Spring Boot to 3.5.13 (Spring Framework 6.2.x with updated ASM).
- **GIT_AVAILABLE=false**: Changes are not version-controlled. Progress is tracked in `progress.md` only.

## Plan Review

- All sections populated. Java version bump from 21 → 25 required a derived Spring Boot upgrade (3.3.5 → 3.5.13) to resolve ASM incompatibility with Java 25 class files.
- Spring Boot 3.5.13 is the latest 3.5.x release (OSS support until 2026-11) with Spring Framework 6.2.x.
- Unfixable limitations: None. All 7 tests pass.
